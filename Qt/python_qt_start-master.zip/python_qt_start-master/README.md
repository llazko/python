# python_qt_start
Sample python Qt project suitable for beginners

    pip install requests PyQt5
    
    $python3 btc.py
